<?php

return [

    'breadcrumb' => 'Llistat',

];
