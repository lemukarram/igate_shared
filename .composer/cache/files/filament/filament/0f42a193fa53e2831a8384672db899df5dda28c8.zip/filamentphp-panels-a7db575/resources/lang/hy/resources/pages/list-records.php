<?php

return [

    'breadcrumb' => 'Ցանկ',

];
